class Coord():
    def __init__(self,x,y,d):
        self.x=x
        self.y=y
        self.d=d
