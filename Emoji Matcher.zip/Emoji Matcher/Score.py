
class Score():
    def __init__(self,score):
        self.score = score
