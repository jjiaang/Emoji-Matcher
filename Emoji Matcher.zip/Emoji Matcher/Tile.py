import Graphics
import stddraw

class Tile():
    pass
