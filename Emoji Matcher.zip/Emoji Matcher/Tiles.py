import stddraw

class Tile():

    def __init__(self,emoji,x,y):
        self.emoji=emoji
        self.x = x
        self.y = y

